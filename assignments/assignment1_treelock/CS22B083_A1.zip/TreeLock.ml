(* TreeLock.ml
 *
 * Tree-based lock implementation for n-thread mutual exclusion
 * Uses Peterson locks at each internal node of a binary tree
 *)
(* ADDED boundary conditions.*)

type t = {
  num_threads : int;
  depth : int;
  nodes : PetersonNode.t array;
}

(* Calculate the depth of the tree needed for n threads *)
let calculate_depth n =
  (* Depth = ceiling(log2(n)) i.e min power 2 s.t 2^p >= n *)
  if n <= 0 then invalid_arg "Number of threads must be positive";
  let rec loop d leaves =
    if leaves >= n then d else loop (d + 1) (leaves * 2)
  in
  loop 0 1

(* Convert thread_id to binary path representation *)
let thread_id_to_path thread_id depth =
  (* Returns array of 0s and 1s representing path from root to leaf *)
  if depth < 0 then invalid_arg "Depth must be non-negative";
  if thread_id < 0 then invalid_arg "thread_id must be non-negative" ; 
  Array.init depth (fun i ->
      let bit_index = depth - 1 - i in
      (thread_id lsr bit_index) land 1) (* check if the bit index bit set or not from highest to lowest significant bit*)

(* Get index of node in array given path from root *)
let path_to_index path level =
  (* Level 0 is root (index 0)
     Left child of i is 2*i + 1
     Right child of i is 2*i + 2 *)
    if level < 0 then invalid_arg "Level must be non-negative";
   let idx = ref 0 in
  for i = 0 to level - 1 do
    idx :=
      if path.(i) = 0 then (2 * !idx) + 1
      else if path.(i) = 1 then (2 * !idx) + 2
      else invalid_arg "Path entries must be 0 or 1"
  done;
  !idx

let create num_threads =
    if num_threads < 0 then invalid_arg "num_threads must be non-negative";
   let depth = calculate_depth num_threads in
  let num_nodes = (1 lsl depth) - 1 in (* number of internal nodes having the binary lock *)
  let nodes = Array.init num_nodes (fun _ -> PetersonNode.create ()) in
  { num_threads; depth; nodes }

(*acquire the locks from leaf to root path*)
let lock tree thread_id =
  if thread_id < 0 || thread_id >= tree.num_threads then invalid_arg "thread_id out of range";
  let path = thread_id_to_path thread_id tree.depth in
  for level = tree.depth - 1 downto 0 do
    let idx = path_to_index path level in
    let side = path.(level) in (* get the thread id from the leaf*)
    PetersonNode.lock tree.nodes.(idx) side
  done

  (* acquire the locks from root to leaf node*)
  (* Just reverse of locking process*)
let unlock tree thread_id =
  if thread_id < 0 || thread_id >= tree.num_threads then invalid_arg "thread_id out of range";
  let path = thread_id_to_path thread_id tree.depth in
  for level = 0 to tree.depth - 1 do
    let idx = path_to_index path level in
    let side = path.(level) in
    PetersonNode.unlock tree.nodes.(idx) side
  done

 
let get_depth tree = tree.depth

let get_num_nodes tree = Array.length tree.nodes

let print_tree_info tree =
  Printf.printf "TreeLock info:\n";
  Printf.printf "  Number of threads: %d\n" tree.num_threads;
  Printf.printf "  Tree depth: %d\n" tree.depth;
  Printf.printf "  Number of Peterson nodes: %d\n" (get_num_nodes tree);
  Printf.printf "  Total Leafs: %d\n" (1 lsl tree.depth)
