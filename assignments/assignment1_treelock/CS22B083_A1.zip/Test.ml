(* temp.ml
 *
 * Simple test suite for TreeLock implementation
 *)

let expect cond msg = if not cond then failwith msg

let expect_invalid_arg f =
  try
    let _ = f () in
    failwith "Expected Invalid_argument"
  with
  | Invalid_argument _ -> ()
  | exn -> failwith ("Unexpected exception: " ^ Printexc.to_string exn)

(** PART 1: UNIT TESTS - Testing Observable Properties **)

let test_calculate_depth () =
  Printf.printf "Unit Test 1: Tree depth calculation...\n%!";
  let cases = [ (1, 0); (2, 1); (3, 2); (4, 2); (5, 3); (8, 3) ] in
  List.iter
    (fun (n, expected) ->
      let t = TreeLock.create n in
      let got = TreeLock.get_depth t in
      expect (got = expected)
        (Printf.sprintf "depth mismatch for n=%d: got=%d expected=%d" n got expected))
    cases;
  Printf.printf "  [PASS]\n%!"

let test_tree_structure () =
  Printf.printf "Unit Test 2: Tree structure properties...\n%!";
  let cases = [ 1; 2; 3; 4; 5; 8 ] in
  List.iter
    (fun n ->
      let t = TreeLock.create n in
      let d = TreeLock.get_depth t in
      let nodes = TreeLock.get_num_nodes t in
      let expected_nodes = (1 lsl d) - 1 in
      expect (nodes = expected_nodes)
        (Printf.sprintf "nodes mismatch n=%d: got=%d expected=%d" n nodes expected_nodes))
    cases;
  Printf.printf "  [PASS]\n%!"

let test_boundary_conditions () =
  Printf.printf "Unit Test 3: Boundary conditions...\n%!";
  ignore (TreeLock.create 1);
  expect_invalid_arg (fun () -> TreeLock.create 0);
  expect_invalid_arg (fun () -> TreeLock.create (-1));
  let t = TreeLock.create 4 in
  expect_invalid_arg (fun () -> TreeLock.lock t (-1));
  expect_invalid_arg (fun () -> TreeLock.lock t 4);
  expect_invalid_arg (fun () -> TreeLock.unlock t (-1));
  expect_invalid_arg (fun () -> TreeLock.unlock t 4);
  Printf.printf "  [PASS]\n%!"

(** PART 2: SEQUENTIAL CORRECTNESS TESTS **)

let test_single_thread () =
  Printf.printf "Sequential Test 1: Single thread lock/unlock...\n%!";
  let t = TreeLock.create 1 in
  let c = ref 0 in
  for _ = 1 to 1000 do
    TreeLock.lock t 0;
    c := !c + 1;
    TreeLock.unlock t 0
  done;
  expect (!c = 1000) "single-thread counter mismatch";
  Printf.printf "  [PASS]\n%!"

let test_sequential_acquisitions () =
  Printf.printf "Sequential Test 2: Sequential acquisitions by multiple threads...\n%!";
  let n = 7 in
  let t = TreeLock.create n in
  let c = ref 0 in
  for _round = 1 to 100 do
    for thread_id = 0 to n - 1 do
      (* threads sequentially access the lock/counter*)
      TreeLock.lock t thread_id;
      c := !c + 1;
      TreeLock.unlock t thread_id
    done
  done;
  expect (!c = n * 100) "sequential acquisitions mismatch";
  Printf.printf "  [PASS]\n%!"

(** PART 3: CONCURRENT CORRECTNESS TESTS **)

let run_counter_test ~name ~num_threads ~iterations () =
  Printf.printf "%s...\n%!" name;
  let tree = TreeLock.create num_threads in
  let counter = Atomic.make 0 in

  let worker thread_id =
    for _ = 1 to iterations do
      TreeLock.lock tree thread_id;
      let old_val = Atomic.get counter in
      Atomic.set counter (old_val + 1);
      TreeLock.unlock tree thread_id
    done
  in

  let domains =
    Array.init (num_threads - 1) (fun i -> Domain.spawn (fun () -> worker (i + 1)))
  in
  worker 0; (* spawn the 0 th in current thread don't create a new one *)
  Array.iter Domain.join domains;

  let final = Atomic.get counter in
  let expected = num_threads * iterations in
  if final = expected then
    Printf.printf "  [PASS] counter = %d (expected %d)\n%!" final expected
  else
    failwith (Printf.sprintf "FAILED: counter = %d (expected %d)" final expected)

let test_two_threads () =
  run_counter_test ~name:"Concurrent Test 1: Two threads" ~num_threads:2 ~iterations:2000 ()

let test_four_threads () =
  run_counter_test ~name:"Concurrent Test 2: Four threads" ~num_threads:4 ~iterations:1500 ()

let test_eight_threads () =
  run_counter_test ~name:"Concurrent Test 3: Eight threads" ~num_threads:8 ~iterations:1000 ()

let test_five_threads () =
  run_counter_test ~name:"Concurrent Test 4: Five threads" ~num_threads:5 ~iterations:1200 ()

let test_stress () =
  run_counter_test ~name:"Concurrent Test 5: Stress test" ~num_threads:8 ~iterations:2500 ()

let test_structure_verification () =
  Printf.printf "Concurrent Test 6: Tree structure verification...\n%!";
  let n = 8 in
  let tree = TreeLock.create n in
  let depth0 = TreeLock.get_depth tree in
  let nodes0 = TreeLock.get_num_nodes tree in
  let expected_nodes = (1 lsl depth0) - 1 in
  if nodes0 <> expected_nodes then failwith "number of internal nodes mismatch";

  let counter = Atomic.make 0 in
  let iterations = 3000 in
(*
worker will : 
  1. acquire , release lock
  2. increment the counter
  3. checks tree structure (get_depth, get_num_nodes) to ensure it stays unchanged under load
*)
  let worker tid =
    for _ = 1 to iterations do
      TreeLock.lock tree tid;
      let v = Atomic.get counter in
      Atomic.set counter (v + 1);
      TreeLock.unlock tree tid;

      (* Re-check structure during concurrent execution *)
      if TreeLock.get_depth tree <> depth0 then failwith "depth changed under load";
      if TreeLock.get_num_nodes tree <> nodes0 then failwith "node count changed under load"
    done
  in

  let ds = Array.init (n - 1) (fun i -> Domain.spawn (fun () -> worker (i + 1))) in
  worker 0;
  Array.iter Domain.join ds;

  let final = Atomic.get counter in
  let expected = n * iterations in
  if final <> expected then
    failwith (Printf.sprintf "counter mismatch: got=%d expected=%d" final expected);

  Printf.printf "  [PASS]\n%!"


let test_performance () =
  Printf.printf "Concurrent Test 7: Performance benchmark...\n%!";
  let start = Sys.time () in
  run_counter_test ~name:"  Benchmark run (8 threads) for 3000 iterations each" ~num_threads:8 ~iterations:3000 ();
  let elapsed = Sys.time () -. start in
  Printf.printf "  CPU time: %.4fs\n%!" elapsed

(* Main test runner *)
let () =
  Printf.printf "=== TreeLock Test Suite ===\n\n%!";

  TreeLock.print_tree_info (TreeLock.create 8);
  Printf.printf "\n%!";

  (* Unit Tests *)
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n%!";
  Printf.printf "PART 1: UNIT TESTS\n%!";
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n%!";
  test_calculate_depth ();
  Printf.printf "\n%!";
  test_tree_structure ();
  Printf.printf "\n%!";
  test_boundary_conditions ();
  Printf.printf "\n%!";

  (* Sequential Tests *)
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n%!";
  Printf.printf "PART 2: SEQUENTIAL CORRECTNESS\n%!";
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n%!";
  test_single_thread ();
  Printf.printf "\n%!";
  test_sequential_acquisitions ();
  Printf.printf "\n%!";

  (* Concurrent Tests *)
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n%!";
  Printf.printf "PART 3: CONCURRENT CORRECTNESS\n%!";
  Printf.printf "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n%!";
  test_two_threads ();
  test_four_threads ();
  test_eight_threads ();
  test_five_threads ();
  test_stress ();
  test_structure_verification ();
  test_performance ();

  Printf.printf "\n=== Test Suite Complete ===\n%!"
